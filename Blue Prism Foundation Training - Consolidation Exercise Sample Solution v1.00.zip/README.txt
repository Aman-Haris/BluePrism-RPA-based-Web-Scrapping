This sample Blue Prism Process Solution has been provided so
that you can check your Consolidation Exercise work. It has been
created using Version 3.00 of Centrix Data Solutions, which contains
changes which affect the Login screen. You can download Version
3.00 of Centrix Data Solutions from Section 1 of Foundation Training.

Please note; this Process Solution is uniquely identifiable and
cannot be submitted for assessment for internal training programs
or training provided by one of our authorised training partners.